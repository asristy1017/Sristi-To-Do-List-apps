package applet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TodoApp {
    private static JFrame frame;
    private static DefaultListModel<String> taskListModel;
    private static JList<String> taskList;
    private static JTextField taskInputField;
    private static JButton addButton, editButton, deleteButton;
    private static ArrayList<String> tasks;

    public static void main(String[] args) {
        tasks = new ArrayList<>();
        
        // Initialize JFrame
        frame = new JFrame("To-Do List");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Initialize the task list model and JList
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Initialize UI components
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        taskInputField = new JTextField(20);
        addButton = new JButton("Add Task");
        editButton = new JButton("Edit Task");
        deleteButton = new JButton("Delete Task");

        panel.add(taskInputField);
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);

        JScrollPane scrollPane = new JScrollPane(taskList);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Add Action Listeners
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addTask();
            }
        });

        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editTask();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteTask();
            }
        });

        // Display the frame
        frame.setVisible(true);
    }

    // Method to add task
    private static void addTask() {
        String taskText = taskInputField.getText().trim();

        if (taskText.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a task.");
        } else {
            taskListModel.addElement(taskText);
            tasks.add(taskText);
            taskInputField.setText("");
        }
    }

    // Method to edit task
    private static void editTask() {
        int selectedIndex = taskList.getSelectedIndex();
        
        if (selectedIndex != -1) {
            String newTaskText = JOptionPane.showInputDialog(frame, "Edit Task:", tasks.get(selectedIndex));

            if (newTaskText != null && !newTaskText.trim().isEmpty()) {
                taskListModel.set(selectedIndex, newTaskText);
                tasks.set(selectedIndex, newTaskText);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a task to edit.");
        }
    }

    // Method to delete task
    private static void deleteTask() {
        int selectedIndex = taskList.getSelectedIndex();
        
        if (selectedIndex != -1) {
            taskListModel.remove(selectedIndex);
            tasks.remove(selectedIndex);
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a task to delete.");
        }
    }
}
